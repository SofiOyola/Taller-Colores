package me.sofi.jetpackcompose

import android.R.attr.left
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import me.sofi.jetpackcompose.ui.theme.JetpackComposeTheme
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.layout.Column
import androidx.compose.ui.res.painterResource
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.absolutePadding
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.ui.Alignment
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import java.nio.file.WatchEvent

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {

            MyScreen()

        }
    }
}

//El preview es como para ayudarme a ver antes del emulador
@Preview(
    showBackground = true, //pantalla fondo
    showSystemUi = true //para que me muestre como el cel
)
@Composable //Para que sea componible le colocamos eso
fun MyScreen(){
    Column(content = {
        //Dibujar un texto
        Text( text = "Sofi O", fontSize = 50.sp)
        //Siempre que usamos sp estamos hablando de textos
        Text( text = "Soy ingeniera de Sistemas", fontSize = 35.sp)
        //Imagen dentro de la columna
        /*Para crearla necesitamos un painter
          el id es para decirle en donde está la img -> id = R.localización.nombre
        */
        val painter = painterResource(id = R.drawable.descarga)
        Image(
            painter = painter, //tambien puedo colocarlo "painterResource(id = R.drawable.descarga)"
                               //así para no crear la variable painter, sino lo coloco de una
            contentDescription = "Imagen de gato" //También se puede dejar nulo
        )
        Row( content = {
            Text(text = "Java", fontSize = 20.sp)
            Text(text = "Python", fontSize = 20.sp)
            Text(text = "C#", fontSize = 20.sp)
            Text(text = "php", fontSize = 20.sp)
        }
        )
    })


    /*
    preguntas
    1. qué es jetpackc
    2. qué es una función composable y cómo la coloco
    3. cual es la diferencia entre el preview y el emulador
     */
}
@Preview(
    showSystemUi = true
)
@Composable
fun Screen2(){
    Column (
        verticalArrangement = Arrangement.Center, //Para colocar todo al centro
        modifier = Modifier
            .padding(18.dp)
        .background(Color.Gray)
        .fillMaxSize() //También pudo colocar fillMaxWidth o fillMaxHeight
        ,content = {

        Row(
            horizontalArrangement = Arrangement.SpaceAround,
            modifier = Modifier
                .background((Color.Cyan))
                .padding(25.dp)
                .fillMaxWidth(),
            content = {
            Text(
                text = "Inicio",
                fontSize = 15.sp,
                modifier = Modifier
                    .background(Color.Magenta)
                    .padding(4.dp)
            )
            //Spacer(modifier = Modifier.width(30.dp)) para colocar el espacio en el ancho
            Text(
                text="Perfil",
                fontSize = 15.sp,
                modifier = Modifier
                    .background(Color.Yellow)
                    .padding(4.dp)
            )

            Text(
                text="Configuración",
                fontSize = 15.sp,
                modifier = Modifier
                    .background(Color.Green)
                    .padding(4.dp)
            )


        })

        Spacer(modifier = Modifier.height(30.dp)) //Para colocar el espacio

        Column (
            horizontalAlignment = Alignment.CenterHorizontally, //Para alinear el texto al centro
            modifier = Modifier
            .background(Color.Cyan)
            .fillMaxWidth()
            .padding(25.dp) //corre hacia la izq
            ,content = {
                Text(
                    text = "Título Principal",
                    fontSize = 15.sp,
                    modifier = Modifier
                        .background(Color.Magenta)
                        .padding(4.dp) //como que rellena tantico
                )
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = "Descripción corta del contenido",
                    fontSize = 15.sp,
                    modifier = Modifier
                        .background(Color.Yellow)
                        .padding(4.dp)
                )
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = "Otro elemento de texto",
                    fontSize = 15.sp,
                    modifier = Modifier
                        .background(Color.Green)
                        .padding(4.dp)
                )
            })
    }

    )
}
